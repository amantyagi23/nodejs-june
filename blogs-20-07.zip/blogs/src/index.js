import express from "express"


// initialize the server
const server = express();

server.use(express.static("public"))
server.set("view engine",'html')

server.get("/api",(req,resp)=>{
    resp.render('index').status(200)
})

server.get("/api/hello",(req,resp)=>{
    resp.send("hello world").status(200)
})



server.post("/api",(req,resp)=>{
    resp.send("hello world").status(200)
})
server.path("/api",(req,resp)=>{
    resp.send("this is api to get something").status(200)
})


server.listen(4500,(error)=>{
    if(error){
        console.log(error);
    }
    else{
        console.log("server started at port 4500")
    }
})

