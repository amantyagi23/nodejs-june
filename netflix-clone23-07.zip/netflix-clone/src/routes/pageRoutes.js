
import {Router} from 'express'

const pageRoutes = Router()

pageRoutes.get('/',(req,resp)=>{
    resp.render('../../view/index.ejs')
})


export default pageRoutes