
import {Router} from 'express'
import { dashboardController, indexPageController, loginPageController } from '../controller/pageController.js'
import { ensureAuth } from '../shared/utils/JWTUtils.js'

const pageRoutes = Router()

pageRoutes.get('/',(req,resp)=>indexPageController(req,resp))


pageRoutes.get('/login',(req,resp)=>loginPageController(req,resp))


pageRoutes.get('/dashboard',ensureAuth,(req,resp,next)=>dashboardController(req,resp,next))

// middleware 
export default pageRoutes