

export const indexPageController = (req,resp)=>{
    resp.render('index',{title:"Netflix-clone",movies:[]});
}


export const loginPageController = (req,resp)=>{
    resp.render('login')
}

export const dashboardController = (req,resp,next)=>{
    console.log("here in dashboard",req.decoded);
    resp.render('dashboard')
}